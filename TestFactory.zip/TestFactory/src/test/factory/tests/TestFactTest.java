package test.factory.tests;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

import com.google.gson.annotations.Until;
import com.thoughtworks.selenium.webdriven.commands.WaitForCondition;

import test.factory.pages.TestFactPages;

public class TestFactTest {
	
	WebDriver driver;
	Document document,document1;
	TestFactPages tfp;
	String a,b;
	
	@BeforeMethod
	  public void abc() throws Exception {
		  System.setProperty("webdriver.chrome.driver","D:\\kavita\\chromedriver.exe");
		  driver=new ChromeDriver();
		  driver.get("https://www.goibibo.com/");
		  System.out.println("Starting Test");
		  tfp=new TestFactPages(driver);
		  tfp.fileOpen();  
	  }

	
  @Test
  public void f() throws InterruptedException {
	  
	//  tfp.textField();
	 driver.findElement(By.xpath("//*[@id='gi_roundtrip_label']")).click();
	 driver.findElement(By.xpath("//*[@id='gosuggest_inputSrc']")).sendKeys("Mumbai");
	 driver.findElement(By.xpath("//*[@id='gosuggest_inputDest']")).sendKeys("Kolkata");
	 
	 

  }
}
