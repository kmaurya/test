package test.factory.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestFactPages {

	WebDriver driver;
	Document document, document1;
	public String fPath, fVal, tPath, tVal, dpath,spath,gpath;

	public TestFactPages(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void fileOpen() {

		try {
			File src = new File("./DataInputs/TestPath.xml");
			System.out.println("Hello");
			FileInputStream fis = new FileInputStream(src);
			SAXReader saxReader = new SAXReader();
			document = saxReader.read(fis);
		} catch (Exception E) {
			System.out.println("noooo");
		}
	}

	// Method for Sending data into textfield
	public void textField()  {
		gpath=document.selectSingleNode("//goibibo/From/round").getText();
		click2(gpath);
		//fPath = document.selectSingleNode("//goibibo/From/path").getText();
		//fVal = document.selectSingleNode("//goibibo/data/val").getText();	
		driver.findElement(By.xpath(document.selectSingleNode("//goibibo/From/path").getText())).click();
		driver.findElement(By.xpath(document.selectSingleNode("//goibibo/From/path").getText())).sendKeys(document.selectSingleNode("//goibibo/data/val").getText());
		click2(document.selectSingleNode("//goibibo/From/path1").getText());
		/*tPath = document.selectSingleNode("//goibibo/From/path1").getText();
		tVal = document.selectSingleNode("//goibibo/data/val1").getText();
		driver.findElement(By.xpath(tPath)).click();
		driver.findElement(By.xpath(tPath)).sendKeys(tVal);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tPath)));
		driver.findElement(By.xpath(tPath)).sendKeys(tVal);
		//driver.findElement(By.xpath(Path)).click();*/
	
		//driver.findElement(By.xpath(tPath)).sendKeys(tVal);
		//calDate(spath);

		//driver.findElement(By.xpath(tPath)).sendKeys(tVal);
		

	}

	// To locate Elements


	// Method for Clicking buttons
	public void click2(String path) {
		// isPresent(path);
		driver.findElement(By.xpath(path)).click();
	}


	// Method for Checking for Alert Present
	public void alertPresent(String alt) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.alertIsPresent());
		String alrt = driver.switchTo().alert().getText();
		System.out.println(alrt);

	}

	// Method for Checking the Visibility of Fields
	public void isPresent(String path) {
		driver.findElement(By.xpath(path)).isDisplayed();
	}

	// Method for Selecting dates from Calender
	public void calDate(String path) {
		driver.findElement(By.xpath(path)).click();
		
	}

	public void click1(String path) {
		driver.findElement(By.xpath(path)).click();
	}
	// Method for Selecting Dropdown value for Travellers
	public void dropDown(String path, int index) {
		driver.findElements(By.xpath(path)).get(index).click();
	}

	// Method for clicking Swap Button
	public void swapButton() {

	}

}
