package test.factory.pages;

import java.io.*;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;


public class TestFactPages {

	WebDriver driver;
	Document document;
	String fpath="//goibibo/path/";
	String gpath="//goibibo/data/";
	String browser_driver,browser_path,browser_name,browser_url;

	//Initializing the constructor and page factory page
	public TestFactPages(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	//Method for opening the xml file
	public void fileOpenXml() throws IOException{

		try {
			File src = new File("./DataInputs/TestPath.xml");
			System.out.println("Hello");
			FileInputStream fis = new FileInputStream(src);
			SAXReader saxReader = new SAXReader();
			document = saxReader.read(fis);
		} 
		catch (Exception E) {
			System.out.println("Xml File not accessible.");
		}
	}
	
	public String getBrowser(String name)
	{
		browser_name=name;
		return browser_name;
	}

	public void fileOpenProperty()
	{
		 try
		 {
			 File src = new File("./DataInputs/urlBrowserType.property");
			 FileInputStream fis=new FileInputStream(src);
			 Properties pro=new Properties();
			 pro.load(fis);
			 browser_driver=pro.getProperty("browser_typeChrome");
			 browser_path=pro.getProperty("browser_pathChrome");
			 browser_url=pro.getProperty("url");
			 
			 System.setProperty(browser_driver,browser_path);
			 driver=new ChromeDriver();
			 driver.get(browser_url);
		
		 }
		 catch(IOException e)
		 {
			 System.out.println(e);
		 }
		  
	}
	
	
	// Method for Sending data into textfield
	public void inputField() throws Exception {
		
		//clickElements();	
	}

	
	/* To locate Elements
	public void locateElements()
	{
		try{
			
		//gpath = document.selectSingleNode("//goibibo/From/round").getText();
		
		//tPath = document.selectSingleNode("//goibibo/From/path1").getText();
		tVal = document.selectSingleNode("//goibibo/data/val1").getText();
		dpath = document.selectSingleNode("//goibibo/From/Depart").getText();
		spath = document.selectSingleNode("//goibibo/data/date").getText();
		gopath = document.selectSingleNode("//goibibo/From/Go").getText();
		cpath = document.selectSingleNode("//goibibo/From/TClass").getText();
		trpath = document.selectSingleNode("//goibibo/From/Traveller").getText();
		}
		catch(Exception E)
		{
			System.out.println("Element not present");
		}
	}*/

	//For sending data
	public void sendData(String spath,String value) throws Exception
	{
		
		
		try
		{
		driver.findElement(By.xpath(spath)).sendKeys(value);
		System.out.println(driver.findElement(By.xpath(spath)).getText());
		Thread.sleep(1000);	
		}
		catch(Exception E)
		{
			E.printStackTrace();
			E.getMessage();
		}
	}
	
	
	/*public String getXpath(String path,String value)
	{
		String v="";
		try{
			//System.out.println("//goibibo/" + path.concat(value));
			String addpath="round";
			String addValue="val";
		 v=document.selectSingleNode(fpath.concat(addpath)).getText();
		System.out.println(v);
		
		}
		catch(Exception E)
		{
			E.getMessage();
			E.printStackTrace();
		}
		return v;
	}*/
	
	
	public void radioButton(String path) {
		//String addpathr="round";
		//String addpatho="oneway";
		//String addpathm="multicity";
		//String a=getXpath(path,addpathr);
		driver.findElement(By.xpath(path)).click();		
	}
	
	/*
	//To add or delete number of travellers
	public void travelButtons() {
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("adultPaxPlus")));
			
			driver.findElement(By.id("adultPaxPlus")).click();
			driver.findElement(By.id("childPaxPlus")).click();
		}
		catch(Exception E)
		{
			System.out.println("Methods not called properly");
		}
	}	

	
	
	// Method for Clicking for fields
	

	
	// Method for Checking for Alert Present
	public void alertPresent(String alt) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.alertIsPresent());
		
		String alrt = driver.switchTo().alert().getText();
		System.out.println(alrt);
	}
	

	// Method for Checking the Visibility of Fields
	public boolean isPresent(String path) {
		return driver.findElement(By.xpath(path)).isDisplayed();
	}

	
	// Method for clicking Elements
	/*public void clickElements()  {
		try
		{
			if(isPresent(gpath))
				click2(gpath);
				driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			if(isPresent(fPath))
				driver.findElement(By.xpath(fPath)).sendKeys(fVal);
				Thread.sleep(1000);
			if(isPresent(tPath))
				driver.findElement(By.xpath(tPath)).sendKeys(tVal);
				Thread.sleep(1000);
			if(isPresent(dpath))
				click2(dpath);
			if(isPresent(spath))
				click2(spath);
			if(isPresent(trpath))
				click2(trpath);
				travelButtons();
			if(isPresent(cpath))
				dropDown(cpath,2);
			if(isPresent(gopath))
				clickButton(gopath);
		}
		catch(Exception E)
		{
			System.out.println("Elements may not be found");
		}
	}

	//Method for go set go button
	public void clickButton(String path) throws Exception {
			driver.findElement(By.xpath(path)).click();
			driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
			WebDriverWait wait1 = new WebDriverWait(driver, 120);
			wait1.until(ExpectedConditions.elementToBeClickable(By.id("fltTcktVoucher")));
			System.out.println("You are successfully navigated to next page.");
	}
	

	// Method for Selecting Dropdown value for Travellers
	public void dropDown(String path, int index) {
		driver.findElements(By.xpath(path)).get(index).click();
	}

	// Method for clicking Swap Button
	public void swapButton() {

	}
	
	*/

}
