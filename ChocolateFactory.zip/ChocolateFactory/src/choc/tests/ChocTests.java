package choc.tests;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import choc.pages.ChocPage;

public class ChocTests {
  
	WebDriver driver;
	ChocPage cadb;
	Document document;
	String browser_driver,browser_path,browser_name,browser_url;
	
	
	@BeforeClass
	public void openXml_Property() throws Exception
	{
		try{
		File src = new File("./Chocolate/ChocType.xml");
		System.out.println("Hello");
		FileInputStream fis = new FileInputStream(src);
		SAXReader saxReader = new SAXReader();
		document = saxReader.read(fis);
		
		File src1 = new File("./Chocolate/ChocolateProp.property");
		FileInputStream fis1=new FileInputStream(src1);
		Properties pro=new Properties();
		pro.load(fis1);
		
	/*	System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.goibibo.com/");
		cadb=new ChocPage(driver);*/
		
		browser_driver=pro.getProperty("browser_typeChrome");
		browser_path=pro.getProperty("browser_pathChrome");
		browser_url=pro.getProperty("url");
		
		System.setProperty(browser_driver,browser_path);
		driver=new ChromeDriver();
		driver.get(browser_url);
		cadb=new ChocPage(driver);
		
		
		 
		
		}
		catch(FileNotFoundException e)
		{
			e.getMessage();
		}

		
	}
	
	
	
	
	@Test
  public void oneWay() throws Exception {
		/*System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.goibibo.com/");
		cadb=new ChocPage(driver);*/
	
	//	cadb.TextField(cadb.getXValue(document,cadb.getxpath("from")),cadb.getXValue(document,cadb.getdata("from")));
		cadb.Click(document.selectSingleNode(cadb.getXmlPath("one")).getText());
		Thread.sleep(1000);
		 cadb.SendValues(cadb.getValue(document, cadb.getXmlData("from")),cadb.getValue(document, cadb.getXmlPath("from")));
		 Thread.sleep(1000);
		 cadb.SendValues(cadb.getValue(document, cadb.getXmlData("to")),cadb.getValue(document, cadb.getXmlPath("to")));
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("cal")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("depart")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("traveller")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("traveller/adult/plus")).getText());
		 Thread.sleep(1000);
		 
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("traveller/child/plus")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("TClass/bu")).getText());
		 Thread.sleep(1000);
		 
		 //cadb.Section(document.selectSingleNode(cadb.getXmlPath("TClass")).getText(),"B");
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("Go")).getText());
		 Thread.sleep(3000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("book")).getText());
		 Thread.sleep(3000);
		 driver.navigate().back();
			Thread.sleep(3000);
			driver.navigate().back();
			Thread.sleep(1000);
		//cadb.ClearVal(document.selectSingleNode(cadb.getXmlData("from")).getText());
			driver.findElement(By.xpath("//*[@id='gosuggest_inputSrc']")).clear();
			Thread.sleep(500);
			 cadb.Click(document.selectSingleNode(cadb.getXmlPath("Go")).getText());
			 Thread.sleep(3000);
		 
			
			 Thread.sleep(1000);

			
		// cadb.SendValues(cadb.getValue(document, cadb.getXmlData("depart")),cadb.getValue(document, cadb.getXmlPath("depart")));
		 //Thread.sleep(1000);
		 
		 
	}
}
