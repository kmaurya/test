package choc.pages;



import java.util.List;

import org.dom4j.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ChocPage {
	WebDriver driver;
	Document document;
	String browser_driver,browser_path,browser_name,browser_url;
	
	

	public ChocPage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	public String getValue(Document document,String xml)
	{
		return document.selectSingleNode(xml).getText();
	}

	
	public String  getXmlPath(String Xml) 
	{
		String s ="//goibibo/path/";
		return s.concat(Xml);
	}

	public String  getXmlData(String Data) 
	{
		String s ="//goibibo/data/";
		return s.concat(Data);
	}


	public void SendValues(String value , String xPath)
	{
	
		   driver.findElement(By.xpath(xPath)).sendKeys(value);
	}
	
	public void Click(String xPath)
    {  
	System.out.println(xPath);       
	
	           driver.findElement(By.xpath(xPath)).click();
	 
    }
	
	
	//For Dropdown
	public void Section(String xPath,String value) throws Exception
	{
		Select clas1=new Select(driver.findElement(By.xpath(xPath)));
		clas1.selectByValue(value);

	}
	
	public void ClearVal(String xPath)
	{
		driver.findElement(By.xpath(xPath)).clear();
	}
	

}
